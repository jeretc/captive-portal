/* Introduction */

Greetings, this is a fake/evil hotspot portal to capture credentials.
It's a deceptive way to get user's social media login accounts.


/* Fake Portal - Harvest User Credentials */
/* This hack was done and tested with ParrotSec */

/* Requirements : 
Wifi-Pumpkin, Apache2 WebServer, Mysql, PhP */

/* Kali & Parrotsec comes with apache, mysql and Php but if you need to install
it manually you can install with this command */

/* Apache2 */
sudo apt-get update
sudo apt-get install apache2

/* Mysql */
sudo apt-get install mysql-server libapache2-mod-auth-mysql php5-mysql

/* Activate mysql */
sudo mysql_install_db
 
/* Finish up installation running the MySQL set up script */
sudo /usr/bin/mysql_secure_installation
 
/* PhP */
sudo apt-get install php5 libapache2-mod-php5 php5-mcrypt


/* For Wifi-Pumpkin installation refer to : */
https://github.com/P0cL4bs/WiFi-Pumpkin/wiki/Installation 


/* The easy method: 

Use this portal with Wifi-Pumpkin, copy the downloaded files to your "www" folder. Download Wifi-Pumpkin : */

https://github.com/P0cL4bs/WiFi-Pumpkin



/* the learning method, do it manually */

http://www.rootsh3ll.com/2015/12/fake-wifi-access-point-walkthrough/

Shout-out to Hardeep Singh (rootsh3ll) www.rootsh3ll.com on the .php script.



Email me "jereted879@gmail.com" for more details, web & graphic design & hacks. 
 


Thanks and have fun!

www.facebook.com/hackprooftips <-- like my page :)



